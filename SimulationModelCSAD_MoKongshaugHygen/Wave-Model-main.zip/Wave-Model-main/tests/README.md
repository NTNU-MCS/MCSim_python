# Wave-Model/Tests

Contains python test files for testing of implemented functionalities.

Run `pytest` in command prompt to run the tests. You can also run `pytest -l` to avoid warnings.
