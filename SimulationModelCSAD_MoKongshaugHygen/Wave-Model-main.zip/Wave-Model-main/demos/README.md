# Wave-Model / Demos

Folder containing simple demonstrations of how modules can be used in program.
