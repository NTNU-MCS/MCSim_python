# Wave-Model/notebooks

Jupyter Notebooks for data analysis and testing of functionalities.
